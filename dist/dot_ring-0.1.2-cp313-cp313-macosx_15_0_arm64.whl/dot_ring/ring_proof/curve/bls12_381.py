# Either use the bls curve ops from helpers or define them here
